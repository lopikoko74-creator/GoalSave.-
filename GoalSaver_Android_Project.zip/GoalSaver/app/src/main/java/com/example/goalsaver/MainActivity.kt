package com.example.goalsaver

import android.app.Activity
import android.app.DatePickerDialog
import android.os.Bundle
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.roundToLong

class MainActivity : Activity() {
    private val dateFmt = DateTimeFormatter.ofPattern("dd.MM.yyyy")
    private lateinit var goalName: EditText
    private lateinit var goalAmount: EditText
    private lateinit var currentSaved: EditText
    private lateinit var deadlineButton: Button
    private lateinit var sourcesBox: LinearLayout
    private lateinit var resultBox: LinearLayout
    private var deadline = LocalDate.now().plusMonths(6)
    private val sources = mutableListOf<IncomeSource>()
    private val prefs by lazy { getSharedPreferences("goal_saver", Context.MODE_PRIVATE) }

    data class IncomeSource(
        val name: String,
        val amount: Double,
        var nextDate: LocalDate,
        val frequency: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadState()
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(30))
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("Копилка целей", 28, true))
        root.addView(label("Укажи цель, доходы и даты поступлений — приложение рассчитает план пополнений.", 15))
        root.addView(spacer(14))

        root.addView(label("1. Твоя цель", 20, true))
        goalName = edit("Например, отпуск или новый ноутбук", prefs.getString("goalName", "") ?: "")
        goalAmount = edit("Сумма цели, например 150000", prefs.getString("goalAmount", "0") ?: "0")
        currentSaved = edit("Уже накоплено (если есть)", prefs.getString("currentSaved", "0") ?: "0")
        root.addView(fieldLabel("Название цели")); root.addView(goalName)
        root.addView(fieldLabel("Сколько нужно накопить (₽)")); root.addView(goalAmount)
        root.addView(fieldLabel("Уже отложено (₽)")); root.addView(currentSaved)
        root.addView(fieldLabel("К какому сроку"))
        deadlineButton = Button(this).apply { text = "Дата: ${deadline.format(dateFmt)}"; setOnClickListener { chooseDate(deadline) { deadline = it; text = "Дата: ${it.format(dateFmt)}"; saveState() } }
        }
        root.addView(deadlineButton, matchWrap())
        root.addView(spacer(16))

        root.addView(label("2. Доходы", 20, true))
        root.addView(label("Добавь зарплату, аванс, подработку или любой другой источник. Для каждого укажи сумму, дату следующего поступления и периодичность.", 14))
        sourcesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(sourcesBox)
        root.addView(Button(this).apply {
            text = "+ Добавить источник дохода"
            setOnClickListener { addSourceEditor("", "", LocalDate.now().plusDays(1), "Ежемесячно") }
        }, matchWrap())
        root.addView(spacer(16))
        root.addView(Button(this).apply {
            text = "Рассчитать план"
            textSize = 17f
            setOnClickListener { calculatePlan() }
        }, matchWrap())
        root.addView(spacer(10))
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(resultBox)

        if (sources.isEmpty()) addSourceEditor("Зарплата", "", LocalDate.now().plusDays(1), "Ежемесячно")
        else {
            val saved = sources.toList()
            sources.clear()
            saved.forEach { addSourceEditor(it.name, it.amount.toString(), it.nextDate, it.frequency) }
        }
    }

    private fun addSourceEditor(name0: String, amount0: String, date0: LocalDate, frequency0: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val name = edit("Название: зарплата / аванс / другое", name0)
        val amount = edit("Сумма поступления (₽)", amount0)
        var date = date0
        val dateBtn = Button(this).apply { text = "Следующее поступление: ${date.format(dateFmt)}" }
        dateBtn.setOnClickListener { chooseDate(date) { date = it; dateBtn.text = "Следующее поступление: ${it.format(dateFmt)}" } }
        val spinner = Spinner(this)
        val frequencies = listOf("Разово", "Еженедельно", "Раз в 2 недели", "Ежемесячно", "Дважды в месяц")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, frequencies)
        spinner.setSelection(frequencies.indexOf(frequency0).coerceAtLeast(0))
        card.addView(fieldLabel("Источник дохода")); card.addView(name)
        card.addView(fieldLabel("Сумма (₽)")); card.addView(amount)
        card.addView(dateBtn, matchWrap())
        card.addView(fieldLabel("Как часто поступает"))
        card.addView(spinner, matchWrap())
        card.addView(Button(this).apply {
            text = "Удалить источник"
            setOnClickListener { sourcesBox.removeView(card); saveState() }
        }, matchWrap())
        card.tag = SourceEditor(name, amount, dateBtn, spinner, { date })
        sourcesBox.addView(card, matchWrap())
    }

    private data class SourceEditor(
        val name: EditText, val amount: EditText, val dateButton: Button,
        val frequency: Spinner, val getDate: () -> LocalDate
    )

    private fun collectSources(): List<IncomeSource> {
        val list = mutableListOf<IncomeSource>()
        for (i in 0 until sourcesBox.childCount) {
            val card = sourcesBox.getChildAt(i) as? LinearLayout ?: continue
            val ed = card.tag as? SourceEditor ?: continue
            val amount = ed.amount.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: 0.0
            if (amount > 0) {
                list.add(IncomeSource(
                    ed.name.text.toString().trim().ifBlank { "Доход ${i + 1}" },
                    amount, ed.getDate(), ed.frequency.selectedItem.toString()
                ))
            }
        }
        return list
    }

    private data class Event(val date: LocalDate, val name: String, val income: Double)

    private fun calculatePlan() {
        resultBox.removeAllViews()
        val target = goalAmount.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val saved = currentSaved.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: 0.0
        if (target == null || target <= 0) { toast("Укажи сумму цели больше нуля."); return }
        if (deadline <= LocalDate.now()) { toast("Срок цели должен быть в будущем."); return }
        if (saved < 0) { toast("Накопленная сумма не может быть отрицательной."); return }
        val remaining = (target - saved).coerceAtLeast(0.0)
        val incomeSources = collectSources()
        if (remaining <= 0) {
            resultBox.addView(label("Цель уже достигнута 🎉", 20, true))
            saveState()
            return
        }
        if (incomeSources.isEmpty()) { toast("Добавь хотя бы один источник дохода с суммой."); return }

        val events = mutableListOf<Event>()
        val today = LocalDate.now()
        for (source in incomeSources) {
            var d = source.nextDate
            if (d < today) d = today
            var guard = 0
            while (!d.isAfter(deadline) && guard < 300) {
                events.add(Event(d, source.name, source.amount))
                guard++
                d = when (source.frequency) {
                    "Еженедельно" -> d.plusWeeks(1)
                    "Раз в 2 недели" -> d.plusWeeks(2)
                    "Дважды в месяц" -> d.plusDays(15)
                    "Ежемесячно" -> d.plusMonths(1)
                    else -> break
                }
            }
        }
        events.sortWith(compareBy<Event> { it.date }.thenBy { it.name })
        if (events.isEmpty()) {
            resultBox.addView(label("До выбранного срока нет запланированных поступлений. Измени дату или срок цели.", 16))
            return
        }
        val totalIncome = events.sumOf { it.income }
        var allocated = 0L
        resultBox.addView(spacer(16))
        resultBox.addView(label("План накоплений", 22, true))
        resultBox.addView(label("Цель: ${goalName.text.toString().ifBlank { "Без названия" }}", 16, true))
        resultBox.addView(label("Осталось накопить: ${money(remaining)} ₽", 16))
        resultBox.addView(label("Поступлений до срока: ${events.size}", 15))
        resultBox.addView(label("В расчёте предполагается, что ты откладываешь часть каждого указанного дохода. Чем больше поступление, тем больше рекомендуемый взнос.", 14))
        resultBox.addView(spacer(8))

        events.forEachIndexed { idx, event ->
            val amount = if (idx == events.lastIndex) {
                (remaining * 100).roundToLong() - allocated
            } else {
                (remaining * event.income / totalIncome * 100).roundToLong().also { allocated += it }
            }.coerceAtLeast(0L)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            row.addView(label(event.date.format(dateFmt) + " · " + event.name, 16, true))
            row.addView(label("Отложить: ${money(amount / 100.0)} ₽ из дохода ${money(event.income)} ₽", 15))
            resultBox.addView(row, matchWrap())
            resultBox.addView(spacer(5))
        }
        resultBox.addView(label("Итого по плану: ${money(remaining)} ₽", 18, true))
        resultBox.addView(label("Это расчётный план: фактический бюджет, обязательные расходы и непредвиденные траты нужно учитывать отдельно.", 13))
        saveState()
    }

    private fun saveState() {
        try {
            val arr = JSONArray()
            for (i in 0 until sourcesBox.childCount) {
                val card = sourcesBox.getChildAt(i) as? LinearLayout ?: continue
                val e = card.tag as? SourceEditor ?: continue
                arr.put(JSONObject().put("name", e.name.text.toString())
                    .put("amount", e.amount.text.toString())
                    .put("date", e.getDate().toString())
                    .put("frequency", e.frequency.selectedItem?.toString() ?: "Ежемесячно"))
            }
            prefs.edit()
                .putString("sources", arr.toString())
                .putString("goalName", if (::goalName.isInitialized) goalName.text.toString() else "")
                .putString("goalAmount", if (::goalAmount.isInitialized) goalAmount.text.toString() else "")
                .putString("currentSaved", if (::currentSaved.isInitialized) currentSaved.text.toString() else "0")
                .putString("deadline", deadline.toString())
                .apply()
        } catch (_: Exception) { }
    }

    private fun loadState() {
        try {
            deadline = LocalDate.parse(prefs.getString("deadline", null) ?: return)
        } catch (_: Exception) { deadline = LocalDate.now().plusMonths(6) }
        try {
            val arr = JSONArray(prefs.getString("sources", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                sources.add(IncomeSource(o.optString("name"), o.optString("amount").toDoubleOrNull() ?: 0.0,
                    LocalDate.parse(o.optString("date")), o.optString("frequency", "Ежемесячно")))
            }
        } catch (_: Exception) { sources.clear() }
    }

    private fun chooseDate(initial: LocalDate, onChosen: (LocalDate) -> Unit) {
        DatePickerDialog(this, { _, y, m, d -> onChosen(LocalDate.of(y, m + 1, d)) },
            initial.year, initial.monthValue - 1, initial.dayOfMonth).show()
    }
    private fun edit(hintText: String, value: String = "") = EditText(this).apply {
        hint = hintText; setText(value); textSize = 16f
        setSingleLine(true)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        inputType = if (hintText.contains("Сумма") || hintText.contains("накопить") || hintText.contains("отложено")) 8194 else 1
        background = getDrawable(android.R.drawable.edit_text)
    }
    private fun fieldLabel(s: String) = label(s, 14, true).apply { setPadding(0, dp(8), 0, dp(3)) }
    private fun label(s: String, size: Int = 16, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(0xFF20252B.toInt())
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(3), 0, dp(3))
    }
    private fun spacer(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = dp(5)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToLong().toInt()
    private fun money(v: Double): String = String.format(Locale.US, "%,.2f", v).replace(',', ' ').replace('.', ',')
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onPause() {
        super.onPause()
        if (::sourcesBox.isInitialized) saveState()
    }
}
